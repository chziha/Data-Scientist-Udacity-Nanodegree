from setuptools import setup

setup(name='distributions_czh',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions_czh'],
      zip_safe=False)
